# Integración local IMP-008 · G05 · 14/11/2026

**Estado:** VALIDATED en integración, cálculo, Windows y navegador. Pendiente aceptación pedagógica con estudiantes reales. No se declara CLOSED ni se hicieron commit, push, merge o publicación.

## Diagnóstico

Checkout vigente: `D:\PlanMinUPN_Integracion\Kai PL Min\PlanMinUPN_G05_Kai_Teoria_R6`. Rama `codex/kai-g05-teoria-s11-s12`; HEAD `7825c2110a111193eb8e069c6358baa0dca0eb3e`. Se inspeccionaron y conservaron los cambios locales válidos de R6, IMP-006 e IMP-007 y sus entradas intent-to-add.

El ZIP original tiene SHA-256 `dcb37b73b36c964c125c8e754b20c29d6674a48e4b7303da3631ae43a196bc4d`; sus 78 archivos coinciden con el manifiesto. En `D:\PlanMinUPN_Integracion\IMP008_G05` faltaba exactamente `proyecto_G05/.github/agents/kai-planeamiento.agent.md`. Los otros 77 archivos eran idénticos. La extracción anidada sí estaba completa. La causa comprobada fue un archivo ausente; no se encontraron diferencias de saltos de línea, BOM o contenido.

Se leyó el reparador antes de ejecutarlo: restauró solo el agente desde el ZIP verificado y comprobó 80 elementos de distribución. No se modificaron hashes esperados. La comparación contra el checkout reconoció 9 actualizaciones con respaldo, 56 incorporaciones y 13 archivos ya aplicados, sin conflicto en 31 guardas. Se revisaron los nueve diffs antes de aplicar por archivo; el checkout no se sustituyó por una copia del ZIP.

## Respaldos

- Checkout previo completo: `D:\PlanMinUPN_Integracion\QA_INTEGRACION_IMP008_G05_20261114\respaldo_checkout_antes.zip`. Es privado: contiene los cuatro archivos individuales y el estado Git; queda fuera de los paquetes compartibles.
- Reparación: `D:\PlanMinUPN_Integracion\RESPALDO_PAQUETE_IMP008_20261114T214245606958Z`.
- Sustituciones del instalador: `D:\PlanMinUPN_Integracion\Kai PL Min\RESPALDO_G05_IMP008_20261114T214342974116Z`.
- Evidencia externa: `D:\PlanMinUPN_Integracion\QA_INTEGRACION_IMP008_G05_20261114`.

## Cambios aplicados

Se integraron `src/missions`, políticas versionadas, controlador `kai/recorrido_g05.py`, aplicación SQLite/Excel V3 de 26 observaciones, pantallas y visores S11/S12, perfil del agente y entrega grupal. Se conservan la teoría aprobada en `#teoria`, el cierre E1, la ficha E1 de 21 observaciones, V1, comprensión V2 y las plantillas previas.

La ejecución Windows detectó conexiones SQLite que no se cerraban al salir del contexto: se añadió `contextlib.closing` en aplicación y controlador, manteniendo las transacciones. Las pruebas heredadas de bloqueo usan el fixture Windows del checkout cuando falta su antigua ruta QA. Se añadió una prueba de bloqueo exclusivo real para V3: guarda en SQLite, recupera el XLSX al liberar el bloqueo y comprueba ausencia de duplicados y handles pendientes.

Los lanzadores prefieren `.venv`, activan UTF-8 y usan `py -3.12` como alternativa. El perfil señala el intérprete del proyecto. El inspector incorpora remanente, tratamiento y desglose de costos/CAPEX; el selector incluye volumen de roca. Los campos se concilian con las relaciones A/B. El ZIP grupal usa rutas estándar y los modelos activos.

## Resultados locales

| Medida | Resultado |
| --- | ---: |
| S11 VALIDATED | `4cc61d4696212e9928cc` |
| Celdas | 11 550 |
| Cu a 75 / 50 m | 168 / 165 bloques |
| Densidad estimada | 942 bloques |
| Tonelaje con densidad y volumen | 62 917 363,048567 t |
| Tonelaje con Cu, densidad y volumen | 11 068 119,924647 t en 168 bloques |
| S12 VALIDATED | `c1b396f1482e4ee1d39d` |
| Mineral candidato | 80 bloques · 5 278 735,095685 t |
| Desmonte candidato | 88 bloques · 5 789 384,828962 t |
| Sin clasificación | 11 382 bloques |
| Relaciones bloque/escenario | 23 100 |
| Asignación por 22 días | 110 000 t movidas · 66 000 t procesadas |

| Escenario | Ciclo | Camiones | CAPEX USD | OPEX USD/22 días |
| --- | ---: | ---: | ---: | ---: |
| A | 30 min | 6 | 2 700 000 | 1 001 000 |
| B | 40 min | 8 | 3 600 000 | 1 001 000 |

Los parámetros numéricos PT-01 permanecen iguales. G05-ALLOC-01 es asignación proporcional conceptual por clase, limitada por metas e inventario; no acredita secuencia, accesibilidad ni reservas profesionales. Se conservan faltantes y causas. La ley de centro es un proxy académico de bloque y CRS/datum topográfico continúan sin acreditar.

## Verificación propia

Se usó `.venv\Scripts\python.exe`, Python 3.12.0, numpy 2.4.3, scipy 1.17.1, plotly 7.1.0 y pytest 8.4.2. El entorno permite paquetes existentes con `--system-site-packages`; no se instalaron paquetes ni se alteraron dependencias globales. Pytest 8.4.2 es anterior al mínimo 9.1 de `requirements.txt`; la evidencia corresponde expresamente a la versión disponible, sin afirmar instalación exacta del manifiesto.

Las pruebas usaron una copia aislada sin historiales reales:

1. `python -m pytest -q --junitxml=.../pytest_final.xml`: **127 aprobadas, cero excluidas**, 123,91 s. Incluye dos bloqueos exclusivos heredados de Windows y el nuevo bloqueo V3. El log inicial conserva los cuatro errores de cierre detectados antes de corregirlos.
2. Después de añadir los campos finales y recalcular: `python -m pytest -q tests/test_g05_products.py tests/test_missions_quantitative.py`: **17 aprobadas**, 8,94 s, con conciliación de campos nuevos y balances. La suite completa corresponde a la generación inmediatamente anterior; estas pruebas y Chrome corresponden a las generaciones finales.
3. `python -m src.missions.g05 todo` y `python -m src.missions.g05 verificar`: ambos productos finales VALIDATED y S12 relacionado con el S11 activo.
4. Chrome 157 real con WebGL por SwiftShader: diez pantallas, iframe de ocho métodos, 11 550 filas por visor, ocho propiedades, consulta por ID y rechazo de ID inexistente, filtros de faltantes y candidatos, A/B, tabla de escenarios y arrastre con cambio de cámara. Cero errores JavaScript y cero solicitudes externas. Se inspeccionaron las cinco capturas. La consulta fue por ID; hover/clic de selección de caja no se declaran comprobados.
5. La comprobación final contrasta hashes de `.kai_local`, raw, preliminares, plantillas originales, M01 y gobernanza, además de los parámetros numéricos y el índice Git lógico. El resumen sin alias está en `outputs/audit_g05/verificacion_final.json`.

PyCharm reconoce y permite seleccionar **Kai Planeamiento**, con `.venv [3.12.0]`. Se envió un ensayo ficticio sin escritura; el proveedor pasó por preparación/actualización automática y espera. No se acredita un intercambio pedagógico completado. Su estado específico queda en `outputs/audit_g05/copilot_pycharm.json`. Los fixtures automáticos no representan comprensión ni aceptación de estudiantes reales.

## Uso

Abre `index.html` en Chrome. La guía está en «Métodos y teoría S11»; en S11 y S12 pulsa «Cargar visor aquí», elige propiedad y consulta un ID. `MISION_S11.cmd`, `MISION_S12.cmd` y `VERIFICAR_PRODUCTOS_G05.cmd` usan el intérprete del proyecto.

En PyCharm abre este checkout, selecciona `.venv\Scripts\python.exe` y **Kai Planeamiento**. En un chat nuevo escribe «Hola Kai, quiero comenzar»; para retomar usa tu alias existente. Kai debe consultar estado, plantear una decisión por turno y guardar solo las respuestas aportadas y verificadas. Cierra los Excel antes de pedir actualización.

La entrega técnica es `outputs/Entregable_Grupal_G05_S11_S12.zip`. La auditoría final reúne código, modelos activos, hashes y evidencia; excluye `.kai_local`, solicitudes, entornos y respaldos privados. El informe y verificación originales del paquete se conservan en `outputs/audit_g05/informe_paquete_origen.md` y `verificacion_paquete_origen.json`, como antecedentes de la ejecución Linux, separados de esta verificación Windows.
