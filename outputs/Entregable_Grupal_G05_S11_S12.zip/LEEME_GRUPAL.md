# Entrega grupal G05

Abre index.html para explorar S11 y S12. Los modelos, controles y relación por bloque están dentro de outputs.

Reproducción: instala requirements.txt y ejecuta `python -m src.missions.g05 todo`; verificación: `python -m src.missions.g05 verificar`.

El archivo no contiene historiales ni respuestas individuales. Los supuestos y límites constan en los reportes y en la política versionada.
